<?php echo validation_errors(); ?>
<?php echo form_open(); ?>

<?php echo form_label('Dolgozó neve:','emp_name'); ?>
<?php echo form_input('name',set_value('name',''),['id' => 'emp_name' , 'required' => 'required']); ?>

<?php echo form_error('name');?>
<br/>
<?php echo form_input('tin',set_value('tin',''), ['placeholder' => 'Adóazonosító','required' =>'required']); ?>


<?php echo form_error('tin');?>
<br/>
<?php echo form_input('ssn',set_value('ssn',''),[ 'placeholder' => 'TAJ','required' => 'required' ]); ?>


<?php echo form_error('ssn');?>
<?php echo form_submit('submit','Beküld'); ?>

<?php echo form_close(); ?>


