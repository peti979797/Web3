create table employees(
    id int not null AUTO_INCREMENT,
    name VARCHAR(250) not null,
    ssn CHAR(9) not null,
    tin CHAR(10) not null,
        
    CONSTRAINT PK_employees PRIMARY KEY(id),
    CONSTRAINT UQ_employees_ssn UNIQUE(ssn),
    CONSTRAINT UQ_employees_tin UNIQUE(tin)
);

insert into employees(name, ssn, tin) values('T1', '012345678','0123456789');
insert into employees(name, ssn, tin) values('T1', '012345672','0123456781');

