<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Employees
 *
 * @author user
 */
class Employees extends CI_Controller {
    public function __construct(){
        parent::__construct();
        
        $this->load->model('employees_model');
        //innentől az emp. model metódusait a $this->employees_model-en keresztül
        //tudjuk hívni
    }
    
    //alkalmazottak listázása
    public function index(){
        
        
        // 1) lekérdezem az adatbázisból a rekordokat
        $records = $this->employees_model->get_list();
        // 2) a rekordok megjelenítése a böngészőben
        $view_params = [
            'employees' => $records
        ];
        $this->load->helper('url'); // segéd az url kezeléshez.
        // 3) Felhelyezem a nézetet + átadom a paramétereket
        $this->load->view('employees/list', $view_params);
        
    }
    
    // alkalmazott hozzáadása
    public function insert(){
        //miért kerültünk ide?
        //A - valaki meghívta első alkalommal ezt a metódust
        //B - valaki kitöltötte az űrlapot és szeretné beküldeni
        // $this->input --> az input kezelést valósítja meg
        if($this->input->post('submit')){
            // valaki rákattintott a submit-ra, az adatokat validálni kell
            // a validációhoz a form_validation könyvtárat használjuk
            $this->load->library('form_validation');
            // validációs szabályok beállítása
            // a) mindhárom mező kitöltése kötelező
            $this->form_validation->set_rules('name','név','required');
            $this->form_validation->set_rules('tin','Adóazonosító','required');
            $this->form_validation->set_rules('ssn','TAJ szám','required');
            
            $this->form_validation->run();
            if($this->form_validation->run() == TRUE){
                //a validáció ok, mehet a beszúrás
                $this->employees_model->insert($this->input->post('name'),
                                               $this->input->post('tin'),
                                               $this->input->post('ssn'));
                // irányítsuk az oldalt listázó nézetre
                $this->load->helper('url');
                //redirect ->átirányítás
                redirect(base_url('employees'));
            }
        }
        
        
        // a nézetben formot szeretnénk kezelni, ezért a helperek
        //közül a form helpert behivatkozom
        $this->load->helper('form');
        $this->load->view('employees/insert');
        
    }
    //alkalmazott módosítása
    public function edit(){
        
    }
    
    //alkalmazott törlése
    public function delete($id){
        // van-e jogosultságom a rekord törléséhez?
        
        // létezik e egyáltalán a törölni kívánt rekord?
        
        // ha minden ok, akkor törlé, majd a listázó oldalra megyünk
        $this->employees_model->delete($id);
        $this->load->helper('url');
        redirect(base_url('employees'));
        
    }
}
