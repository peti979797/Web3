<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Employees_model
 *
 * @author user
 */
class Employees_model extends CI_Model {
    public function __construct() {
        parent::__construct();
        
        $this->load->database();
        //innentől kezdve lesz db kapcsolatom
        //innentől kezdve a példányban
        //a $this->db mezőn keresztül érem el
        //az adatbázist
    }    
    
    //visszaadja a rekordokat szűrés nélkül
    public function get_list(){
        $this->db->select('*'); // SELECT *
        $this->db->from('employees'); // FROM employees
        // ?? kell-e where feltétel?
        // ?? kell-e rendezni?
        $this->db->order_by('name','ASC'); //ORDER BY name ASC
        
        $query = $this->db->get(); // lekérdezés OBJEKTUM!!!!
        $result = $query->result(); // lekérd. végrehajtása + rekordok betöltése
        
        return $result;
        
    }
    
    // a kapott adatok alapján szúrjon be egy rekordot a db-be
    public function insert($name, $tin, $ssn){
        // 1) készítsünk egy asszociatív tömböt a rekord számára
        // ehhez a kulcs legyen a mezőnév, az érték pedig a beszúrandó érték
        $records=[
            'name' => $name,
            'tin' =>$tin,
            'ssn' =>$ssn
        ];
        // 2) hívjuk meg az insert metódust
        // a) elég tudnom azt, hogy a beszúrás megtörtént 
        return $this->db->insert('employees', $records);
        
        //b) határozzuk meg a beszúrt rekord AI típusú PK értékés
        return $this->db->insert('id');
        
    }
    public function delete($id){
        $this->db->where('id',$id);
        return $this->db->delete('employees');
    }
    
}
